package HelloWorldProject;

public class main {
		
	public main() {
		//TODO Auto-generated constructor stub
	}//end function
	
	public static void main(String[] args) {
		System.out.println( "Hello World" );
		//TODO Auto-generated method stub
	}//end function
	
}//end class
